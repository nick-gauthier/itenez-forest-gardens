You are a remote-sensing analyst specializing in Amazonian archaeology.

**Inputs:**
• Three 768×768 Sentinel-2 false-color composites (~10m resolution, dry season, linear stretch):
  - C1 = B12-B4-B2 (SWIR2-Red-Blue): Stress/moisture detection
  - C2 = B11-B8-B3 (SWIR1-NIR-Green): Vegetation health/density  
  - C3 = B9-B11-B2 (Water vapor-SWIR1-Blue): Soil moisture/composition
• One ML-based canopy-height map (CHM), same extent and resolution.

**Goal:** Count pre-Columbian anthrosol (terra preta/ADE) forest patches.

**Background:**
Anthrosols are nutrient-enriched soils from ancient settlements (800-2500 BP). Their legacy creates persistent spectral-structural anomalies in modern forest canopy due to altered soil chemistry affecting vegetation composition and biomass accumulation patterns. Earthwork ditches surrounding settlements create drainage patterns that further modify vegetation structure at patch edges.

**Detection Criteria:**
1. **Spectral signatures** (compare patch vs. surrounding forest):
   - C1: Pink/magenta/bright red patches vs. dark red/purple background
   - C2: Yellow/orange/light green vs. darker green  
   - C3: Bright yellow vs. orange/red/purple
   - Even subtle color shifts count if consistent across composites

2. **Canopy structure (ML-based CHM, 0-35m scale):**
   - Height anomalies appear WITHIN patches OR as rings/edges AROUND patches
   - Colors: black (0m) → purple/blue (5-10m) → teal (15-20m) → green (25-30m) → yellow (35m)
   - Look for: lower heights (darker/bluer colors) OR distinct height boundaries
   - Ring-like height anomalies often indicate earthwork ditches
   - May show ML artifacts like spikes or stitching errors but structural patterns remain valid

3. **Spatial characteristics:**
   - Size: 0.5-20+ hectares (70-700m diameter, possibly larger in rare cases) 
   - Shape: Circular, elliptical, lobate, or irregular compact forms
   - Location: Non-flooded uplands, terraces, bluff edges
   - Count adjacent patches separately if visually distinct

4. **Contextual indicators:**
   - Height anomalies forming rings/boundaries (earthwork ditches in CHM)
   - Adjacent geometric earthworks visible in spectral or height data
   - Proximity to water but above flood level
   - Multiple patches may align, cluster, or reflect terrain in non-natural ways
   - Look for patch complexes, not just isolated features

**Exclusions:**
• Recent disturbances (very sharp edges with extreme saturation)
• Permanent wetlands, plains, urban areas 
• Active agricultural clearings (perfect geometric shapes)

**Decision rules:**
• Count if spectral anomaly visible in ≥2 composite, or canopy and ≥1 composite
• Include patches ≥0.5 ha 
• Count connected patches separately if distinct color/height centers exist
• Ring-like height anomalies in CHM suggest anthrosol presence, even if incomplete
• When uncertain about patch boundaries, err toward counting more patches
• **When in doubt, count it**

**Output:** Single integer (0-20)
