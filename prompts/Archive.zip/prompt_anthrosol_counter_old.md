**Role:** Remote-sensing analyst specializing in Amazonian archaeology.

**Input (all 768×768 images, \~10m resolution, dry-season, linear stretch):**

-   **C1:** False-color RGB (R=B12 SWIR₂, G=B4 red, B=B2 blue): vegetation stress/moisture (bright red is dry)

-   **C2:** False-color RGB (R=B9 water-vapor absorption, G=B11 SWIR₁, B=B2 blue): canopy evapotranspiration/moisture (bright yellow is dry)

-   **CHM:** ML-based canopy height map (0–35m scale; black=0m→purple/blue=low→green=mid→yellow=high)

**Goal:** Count pre-Columbian anthrosol (terra preta/ADE) forest patches.

**Background:** Anthrosols are nutrient-enriched soils from ancient settlements (800-2500 BP). Their legacy creates persistent spectral-structural anomalies in modern forest canopy due to altered soil chemistry affecting vegetation composition and biomass accumulation patterns. Earthwork ditches surrounding settlements create drainage patterns that further modify vegetation structure at patch edges.

**Detection Criteria:**

1.  **Spectral:** Anomalies clearly visible in **both** images:
    -   **C1:** Bright red/pink/magenta vs. dark red/purple forest.
    -   **C2:** Bright yellow/orange vs. red/orange/purple forest.
    -   Must be distinct, not subtle gradations. Either solid patch of color or ring-like boundary.
    -   **Size:** ≥5 hectares (≥20 pixels wide).
2.  **Canopy structure:**
    -   Height anomalies appear WITHIN patches OR as rings/edges AROUND patches
    -   Look for: lower heights (darker/bluer colors) OR distinct height boundaries
    -   CHM anomalies have high sensitivity but low specificity for anthrosols
    -   CHM supports identification but is NOT required - spectral evidence is primary
3.  **Spatial characteristics:**
    -   Size: Range 5-700 hectares, 250m-7km diameter (25-700 pixels)
    -   Shape: Circular, elliptical, lobate, or irregular compact forms
    -   Location: Non-flooded uplands, terraces, bluff edges
    -   Count adjacent patches separately if \>250m apart OR spectral valley between them drops \>75% toward background
4.  **Contextual indicators:**
    -   Multiple patches may align, cluster, or otherwise reflect a broader settlement pattern or network
    -   Proximity to water or seasonally wet areas but above flood level
    -   Adjacent geometric earthworks visible in spectral or canopy height data (faint, narrow, straight, linear features radiating from patches or connecting them, more likely to be visible as anomalies in tree growth and height reflecting underlying earthworks than the earthworks themselves

**Exclusions:**

-   Areas bright in only ONE satellite false color image (must appear in both)

-   Clear anomalies in the CHM without matching anomalies in the satellite images

-   Recent disturbances

-   Spectral anomalies must indicate vegetation differences **within** forest canopy. Forest patches that stand out only because they are surrounded by grassland do not count.

-   Permanent wetlands, plains, urban areas (generally blue/green/gray/navy/teal in satellite images)

-   Active agricultural clearings (perfect geometric shapes)

-   Subtle, smooth, variations in otherwise uniform forest canopy

**Decision rules:**

-   Count ONLY if spectral anomaly visible in BOTH C1 AND C2 images

-   Include patches ≥5 ha (≥20 pixels wide)

-   Count connected patches separately if distinct color/height centers exist (roughly \>250m apart)

-   For marginal cases (weak contrast or \~5ha size), require stronger contextual evidence

-   Default to separating patches with distinct cores rather than merging

**Output:** Single integer (0-30). Do not say anything else or explain your reasoning.
